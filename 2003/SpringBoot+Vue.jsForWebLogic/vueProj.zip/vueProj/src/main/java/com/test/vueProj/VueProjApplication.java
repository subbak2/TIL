package com.test.vueProj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VueProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(VueProjApplication.class, args);
	}

}
