package com.test.vueProj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VueProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
